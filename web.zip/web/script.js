let productos = [];

function agregarProducto() {

  let inputCodigo = document.getElementById("codigo").value; 
  let inputNombre = document.getElementById("nombre").value;
  let inputPrecio = parseFloat(document.getElementById("precio").value); 
  let inputCantidad = parseInt(document.getElementById("cantidad").value);

  if  (inputNombre === "" || isNaN(inputPrecio) || isNaN(inputCantidad)) { 
    alert("Porfis, complete todos los campos con valores válidos.");
    return;
}
  
  let producto = {
    codigo: inputCodigo,
    nombre: inputNombre,
    precio: inputPrecio,
    cantidad: inputCantidad,
  };

  productos.push(producto);

  document.getElementById("codigo").value = "";
  document.getElementById("nombre").value = "";
  document.getElementById("precio").value = "";
  document.getElementById("cantidad").value = "";

  actualizarInterfaz()
}

function actualizarInterfaz() {

  let tablaBody = document.getElementById("tabla-body");

  tablaBody.innerHTML = "";

  let totalInventario = 0;


  for (let i = 0; i < productos.length; i++) {

    let p = productos[i];

    let valor = p.precio * p.cantidad;

    totalInventario += valor;

    let fila = <tr>

      <td>${i + 1}</td>
      <td>${p.codigo}</td>
      <td>${p.nombre}</td>
      <td>Q ${p.precio}</td>
      <td>${p.cantidad}</td>
      <td>Q ${valor}</td>

    </tr>;

    tablaBody.innerHTML += fila;
  }

  document.getElementById("total-inventario").innerText =
    "Q " + totalInventario;
}